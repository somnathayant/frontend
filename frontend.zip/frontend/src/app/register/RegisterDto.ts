export class RegisterDto{
	 id:string;
     userid:string;
	 email:string
	 password:string

}