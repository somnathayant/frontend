import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { EmpService } from 'src/app/service/employeeService.component';
import { RegisterDto } from './RegisterDto';
import {UserServiceService} from '../service/user-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user:FormGroup;
  empDtoObj: RegisterDto;
  submitted = false;
  constructor(private fb: FormBuilder,private userService:UserServiceService,private route:Router) { }

  ngOnInit(): void {
this.submitted=false;
    this.user
     = this.fb.group({
      'password': ['',[Validators.required,Validators.minLength(3)]],
      'email': ['',Validators.required]
     
      
    });
  }
  get f() { return this.user.controls; }
  saveUser(user:RegisterDto) {//same identical property for the formcontrolname
    this.submitted=true;
   
    
    if(this.user.invalid){
      return ;
    }
    this.userService.register(user).subscribe((data) => {
        
        alert("User registered !");
        this.route.navigateByUrl('/login');

    },
      err => {
        alert("User not registered !");
      },
      () => { console.log('Method Executed') }
    ); 
  }
}
