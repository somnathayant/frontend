import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CheckComponent} from './check/check.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {DashboardComponent}from './dashboard/dashboard.component';
import { BookEntryComponent } from './book-entry/book-entry.component';
const routes: Routes = [
 // { path: 'emp', loadChildren: () => import('./emp/emp.module').then(e =>e.EmpModule) },
   { path: 'login', component:LoginComponent },
   { path: 'register', component:RegisterComponent },
   { path: 'dashboard', component:DashboardComponent },
   { path: 'bookEntry', component:BookEntryComponent }
  ];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
