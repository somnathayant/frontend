import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
import { RegisterDto } from '../register/RegisterDto';
@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  url: string;
  emp:RegisterDto;
  empArray:RegisterDto[];
  awsUrl:string;
  constructor(private nativeHttp: HttpClient) {

  }
  register(user: RegisterDto): Observable<RegisterDto> {
  
    this.url="http://localhost:8082/register";
     return this.nativeHttp.post<RegisterDto>(this.url,user);
  }
  login(user: RegisterDto): Observable<RegisterDto> {
    this.url="http://localhost:8082/login";
     return this.nativeHttp.post<RegisterDto>(this.url,user);
  }
  
  
  users():Observable<RegisterDto[]> {
    this.url="http://localhost:8082/employees";
     //return this.nativeHttp.get(this.url).map(res => res.json());
     return this.nativeHttp.get<RegisterDto[]>(this.url);
  }

  getEmpById(id:number):Observable<RegisterDto> {
    this.url="http://localhost:8082/getEmpById";
     //return this.nativeHttp.get(this.url).map(res => res.json());
     return this.nativeHttp.get<RegisterDto>(this.url+"/"+id);
  }

}