import { Injectable } from '@angular/core';
import { BookDto} from '../book-entry/BookDto';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
@Injectable({
  providedIn: 'root'
})
export class BookServiceService {

  url: string;
  book:BookDto;
  bookList:BookDto[];
  awsUrl:string;
  constructor(private nativeHttp: HttpClient) {

  }
  bookListing(user: BookDto): Observable<BookDto> {
  
    this.url="http://localhost:8082/bookListing";
     return this.nativeHttp.post<BookDto>(this.url,user);
  }
  
}