import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { EmpService } from 'src/app/service/employeeService.component';
import { BookDto} from './BookDto';
import {BookServiceService} from '../service/book-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-entry',
  templateUrl: './book-entry.component.html',
  styleUrls: ['./book-entry.component.css']
})
export class BookEntryComponent implements OnInit {

  user:FormGroup;
  empDtoObj: BookDto;
  submitted = false;
  constructor(private fb: FormBuilder,private bookService:BookServiceService,private route:Router) { }

  ngOnInit(): void {
this.submitted=false;
    this.user
     = this.fb.group({
      'password': ['',[Validators.required,Validators.minLength(3)]],
      'email': ['',Validators.required]
     
      
    });
  }
  get f() { return this.user.controls; }
  saveUser(book:BookDto) {//same identical property for the formcontrolname
    this.submitted=true;
    if(this.user.invalid){
      return ;
    }
    this.bookService.bookListing(book).subscribe((data) => {
        
        alert("Book is registered!");
       // this.route.navigateByUrl('/login');

    },
      err => {
        alert("Book is  not registered !");
      },
      () => { console.log('Method Executed') }
    ); 
  }
}

