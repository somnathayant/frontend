export class BookDto{
    id:string;
    bookid:string;
    genre:string
    available:string
    title:string;
    bookauthor:string;
    bookcondition:string;
    usrid:string;
    loc:string;

}